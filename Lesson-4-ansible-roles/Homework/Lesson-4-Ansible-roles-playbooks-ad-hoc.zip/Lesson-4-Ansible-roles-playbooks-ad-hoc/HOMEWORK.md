# Lesson 4 — Ansible Roles & Playbooks · Homework

**Topics:** role directory structure (`tasks/`, `handlers/`, `templates/`, `vars/`), `notify`/handlers,
idempotency, `site.yaml` mapping roles to host groups, `--limit`, tags.

> Use the `webserver` and `database` roles already in this folder as your reference — you're
> extending them, not starting from a blank page.

---

## Part A — Read before you touch anything

Answer these in `answers.md`, in your own words (2–3 sentences each):

1. Why does `roles/webserver/tasks/main.yaml` get run automatically just because `site.yaml` says
   `roles: [webserver]` — what is Ansible actually doing to find it?
2. `handlers/main.yaml` has a `Restart nginx` handler. Under what condition does it actually run,
   and what would happen if you turned it into a normal task instead?
3. `vars/main.yaml` defines `web_packages`. Where in `tasks/main.yaml` is that variable used, and
   what happens if you add a third package to the list?

## Part B — Extend the `webserver` role

1. Add a third package to `web_packages` in `roles/webserver/vars/main.yaml` (e.g. `htop`).
2. Add a new task to `roles/webserver/tasks/main.yaml` that deploys a **second** template file of
   your choice (e.g. a custom `robots.txt` or a `motd` banner) — you'll need a new file under
   `templates/`.
3. Run `ansible-playbook site.yaml --limit web` and confirm only the web hosts were touched (the
   `db` play should show `0` tasks for its hosts).
4. Run the exact same command a **second time** and paste the output. Point at the `changed=0`
   line and explain in one sentence why nothing changed the second time.

## Part C — Extend the `database` role

1. Add a task to `roles/database/tasks/main.yaml` that creates a database using the `mysql_db`
   module (name it anything, e.g. `app_db`).
2. Run `ansible-playbook site.yaml --limit db` and confirm it applies only to the `db` host(s).

## Deliverables

- `answers.md` with Part A's answers and the command output pairs from Part B.3–B.4.
- Your edited `roles/webserver/vars/main.yaml`, the new template file, and the updated
  `roles/database/tasks/main.yaml`.

## Bonus

- Scaffold a brand-new role with `ansible-galaxy init roles/monitoring` and compare its generated
  folders to `roles/webserver` — list which folders `webserver` doesn't use, and why that's fine.
- Add `tags: ['webserver']` / `tags: ['database']` to the two roles in `site.yaml` and run
  `ansible-playbook site.yaml --tags webserver` — confirm it behaves the same as `--limit web` did,
  and explain in 2 lines a situation where `--tags` can do something `--limit` can't.
